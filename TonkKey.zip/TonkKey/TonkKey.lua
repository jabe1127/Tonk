-- TonkKey: one key. Out of the tonk = summon tonk (pet out) or Call Pet (no pet).
-- In the tonk = counts presses; exits only on press number N. Every press is a real keypress.

local TK = CreateFrame("Frame", "TonkKeyFrame")
local db
local defaults = { key = nil, need = 3 }
local function print_(m) DEFAULT_CHAT_FRAME:AddMessage("|cff7fd8ffTonkKey:|r " .. tostring(m)) end

local btn = CreateFrame("Button", "TonkKeyButton", nil, "SecureActionButtonTemplate")
btn:RegisterForClicks("AnyDown")
btn:SetAttribute("type", "macro")
btn:SetAttribute("count", 0)
btn:SetAttribute("need", 3)

SecureHandlerWrapScript(btn, "OnClick", btn, [[
    local inTonk = SecureCmdOptionParse("[possessbar] 1; 0") == "1"
    local n = self:GetAttribute("count") or 0
    if inTonk then
        n = n + 1
        if n >= (self:GetAttribute("need") or 3) then
            self:SetAttribute("macrotext", "/click PossessButton2")
            n = 0
        else
            self:SetAttribute("macrotext", "")
        end
    else
        n = 0
        self:SetAttribute("macrotext", "/use [pet] Steam Tonk Controller\n/cast [nopet] Call Pet")
    end
    self:SetAttribute("count", n)
]])

local pending = false
local function Apply()
    if InCombatLockdown() then pending = true return end
    pending = false
    btn:SetAttribute("need", db.need)
    btn:SetAttribute("count", 0)
    ClearOverrideBindings(TK)
    if db.key then SetOverrideBindingClick(TK, true, db.key, "TonkKeyButton") end
end

SLASH_TONKKEY1 = "/tonk"
SlashCmdList["TONKKEY"] = function(msg)
    local cmd, arg = (msg or ""):match("^%s*(%S*)%s*(.-)%s*$")
    cmd = cmd:lower()
    if cmd == "key" and arg ~= "" then
        db.key = arg:upper()
        Apply()
        print_("key = " .. db.key .. (pending and " (applies after combat)" or ""))
    elseif cmd == "key" then
        db.key = nil; Apply(); print_("key cleared")
    elseif cmd == "need" and tonumber(arg) then
        db.need = math.max(1, math.floor(tonumber(arg)))
        Apply()
        print_("exit on press " .. db.need .. " inside the tonk")
    else
        print_("key: " .. tostring(db.key) .. "   presses needed in tonk: " .. db.need)
        print_("/tonk key F7    (or SHIFT-F7, CTRL-4, BUTTON4 ...)   |   /tonk key  = clear")
        print_("/tonk need 3    (raise if you still get stuck, lower if it feels slow)")
    end
end

TK:RegisterEvent("PLAYER_LOGIN")
TK:RegisterEvent("PLAYER_REGEN_ENABLED")
TK:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        TonkKeyDB = TonkKeyDB or {}
        db = TonkKeyDB
        for k, v in pairs(defaults) do if db[k] == nil then db[k] = v end end
        Apply()
        if not db.key then print_("No key set. Type /tonk key F7 (or whatever key you want).") end
    elseif event == "PLAYER_REGEN_ENABLED" and pending then
        Apply()
    end
end)
